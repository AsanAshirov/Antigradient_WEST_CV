CarPrint — example photos for the jury / примеры фото для жюри

- damage/prius_rear_quarter.jpg: Toyota Prius: crushed rear quarter — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 818.png — CC0 1.0
- damage/peugeot_rear.jpg: Peugeot 207: rear corner impact — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 1284.png — CC0 1.0
- damage/megane_quarter_dent.jpg: Renault Mégane CC: rear quarter dent — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 233.png — CC0 1.0
- damage/micra_front_dent.jpg: Nissan Micra: front dent — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 286.png — CC0 1.0
- damage/touareg_glass.jpg: VW Touareg: broken glass, door — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 421.png — CC0 1.0
- damage/rx8_hood.jpg: Mazda RX-8: damaged bonnet — HITL Car Parts & Damages, held-out split (seed 42) — not used in training: Car parts dataset/File1/img/Car damages 784.png — CC0 1.0
- /evidence/ref.jpg: Same car, two visits — Wikimedia Commons, Damian B Oh, Daewoo Matiz Groove M300 series — CC BY-SA 4.0
